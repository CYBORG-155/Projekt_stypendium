var searchData=
[
  ['sredniasemestralna_46',['SredniaSemestralna',['../namespace_srednia_semestralna.html',1,'']]],
  ['subjectcreation_47',['subjectCreation',['../class_srednia_semestralna_1_1_form1.html#a75a661891af00f9d1d1f68a81ce6ac4c',1,'SredniaSemestralna::Form1']]]
];
