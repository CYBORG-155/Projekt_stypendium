var searchData=
[
  ['groupbox1_5fenter_69',['groupBox1_Enter',['../class_srednia_semestralna_1_1_form1.html#a8bbac943109ddee98a2f8e0948d8ea7c',1,'SredniaSemestralna::Form1']]],
  ['groupbox_5fenter_70',['groupBox_Enter',['../class_srednia_semestralna_1_1_form1.html#abad9c0fe72dfd32410b120750f5da4ab',1,'SredniaSemestralna::Form1']]]
];
