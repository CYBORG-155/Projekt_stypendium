var searchData=
[
  ['label10_5fclick_72',['label10_Click',['../class_srednia_semestralna_1_1_form1.html#ae6c94fa0bda6358f803368ed6946bf24',1,'SredniaSemestralna::Form1']]],
  ['label4_5fclick_73',['label4_Click',['../class_srednia_semestralna_1_1_form1.html#a63eecd73a6fe51888f8c9587666674af',1,'SredniaSemestralna::Form1']]]
];
