var searchData=
[
  ['pad_35',['pad',['../class_srednia_semestralna_1_1_form1.html#adcd41bcc2367bcc4481d38a81374122a',1,'SredniaSemestralna::Form1']]],
  ['program_2ecs_36',['Program.cs',['../_program_8cs.html',1,'']]]
];
