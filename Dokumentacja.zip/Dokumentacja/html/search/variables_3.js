var searchData=
[
  ['groupbox_85',['groupBox',['../class_srednia_semestralna_1_1_form1.html#a7e445af583973070d02e14cae1d6fe24',1,'SredniaSemestralna::Form1']]]
];
