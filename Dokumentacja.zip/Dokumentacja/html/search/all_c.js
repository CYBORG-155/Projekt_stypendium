var searchData=
[
  ['textbox1_48',['textBox1',['../class_srednia_semestralna_1_1_form1.html#a2dd6fcd780316ebafbfaa35ed3c263b5',1,'SredniaSemestralna::Form1']]],
  ['textbox1_5ftextchanged_49',['textBox1_TextChanged',['../class_srednia_semestralna_1_1_form1.html#aa39a8278890cef7cdccbfcec0e0b3a0f',1,'SredniaSemestralna::Form1']]],
  ['textbox2_50',['textBox2',['../class_srednia_semestralna_1_1_form1.html#a3dc31ddb0eca5e1bb970779943dd181a',1,'SredniaSemestralna::Form1']]],
  ['textbox2_5ftextchanged_51',['textBox2_TextChanged',['../class_srednia_semestralna_1_1_form1.html#acbddd026ba410b247d3d1a7abb0d766c',1,'SredniaSemestralna::Form1']]],
  ['textboxaverage_52',['textBoxAverage',['../class_srednia_semestralna_1_1_form1.html#a0079f2bede89e280306a8537fc179b98',1,'SredniaSemestralna::Form1']]],
  ['textboxaverage_5ftextchanged_53',['textBoxAverage_TextChanged',['../class_srednia_semestralna_1_1_form1.html#a837ba5ace6137bf30d2f192ee958a0fa',1,'SredniaSemestralna::Form1']]],
  ['textboxpoints_54',['textBoxPoints',['../class_srednia_semestralna_1_1_form1.html#a0bc433b3dd4b7f6f3a74dd66c7204e99',1,'SredniaSemestralna::Form1']]],
  ['textboxpoints_5ftextchanged_55',['textBoxPoints_TextChanged',['../class_srednia_semestralna_1_1_form1.html#a3685819ac4ad239f9e42f384f4ca3093',1,'SredniaSemestralna::Form1']]]
];
