var searchData=
[
  ['firsttime_8',['firstTime',['../class_srednia_semestralna_1_1_form1.html#a4c211d73d32d63d1956cbb6528b69bc1',1,'SredniaSemestralna::Form1']]],
  ['form1_9',['Form1',['../class_srednia_semestralna_1_1_form1.html#a32c5ffb42aa9204c533afadbc8782156',1,'SredniaSemestralna.Form1.Form1()'],['../class_srednia_semestralna_1_1_form1.html',1,'SredniaSemestralna.Form1']]],
  ['form1_2ecs_10',['Form1.cs',['../_form1_8cs.html',1,'']]],
  ['form1_2edesigner_2ecs_11',['Form1.Designer.cs',['../_form1_8_designer_8cs.html',1,'']]]
];
