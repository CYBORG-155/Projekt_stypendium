var searchData=
[
  ['initializecomponent_16',['InitializeComponent',['../class_srednia_semestralna_1_1_form1.html#ad660b0199fd27f220c3d61e381efe335',1,'SredniaSemestralna::Form1']]]
];
