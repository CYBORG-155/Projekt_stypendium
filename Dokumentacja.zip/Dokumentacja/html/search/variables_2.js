var searchData=
[
  ['firsttime_84',['firstTime',['../class_srednia_semestralna_1_1_form1.html#a4c211d73d32d63d1956cbb6528b69bc1',1,'SredniaSemestralna::Form1']]]
];
