var searchData=
[
  ['buttonpressme_81',['buttonPressMe',['../class_srednia_semestralna_1_1_form1.html#aedd974916ff57c2470ff115e9648a08a',1,'SredniaSemestralna::Form1']]],
  ['buttonsum_82',['buttonSum',['../class_srednia_semestralna_1_1_form1.html#a5937de9fd566bc72b5a74c3f510d52ed',1,'SredniaSemestralna::Form1']]]
];
