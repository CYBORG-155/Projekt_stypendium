var searchData=
[
  ['sredniasemestralna_58',['SredniaSemestralna',['../namespace_srednia_semestralna.html',1,'']]]
];
