var searchData=
[
  ['textbox1_110',['textBox1',['../class_srednia_semestralna_1_1_form1.html#a2dd6fcd780316ebafbfaa35ed3c263b5',1,'SredniaSemestralna::Form1']]],
  ['textbox2_111',['textBox2',['../class_srednia_semestralna_1_1_form1.html#a3dc31ddb0eca5e1bb970779943dd181a',1,'SredniaSemestralna::Form1']]],
  ['textboxaverage_112',['textBoxAverage',['../class_srednia_semestralna_1_1_form1.html#a0079f2bede89e280306a8537fc179b98',1,'SredniaSemestralna::Form1']]],
  ['textboxpoints_113',['textBoxPoints',['../class_srednia_semestralna_1_1_form1.html#a0bc433b3dd4b7f6f3a74dd66c7204e99',1,'SredniaSemestralna::Form1']]]
];
