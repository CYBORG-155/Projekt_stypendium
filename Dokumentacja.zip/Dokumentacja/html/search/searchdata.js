var indexSectionsWithContent =
{
  0: "bcdfghilmprstx",
  1: "f",
  2: "s",
  3: "fpr",
  4: "bcdfgilmrst",
  5: "bcfghlprtx"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Przestrzenie nazw",
  3: "Pliki",
  4: "Funkcje",
  5: "Zmienne"
};

