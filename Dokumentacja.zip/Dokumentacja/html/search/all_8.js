var searchData=
[
  ['makeme_34',['makeMe',['../class_srednia_semestralna_1_1_form1.html#ab0f8b3a6ef5e37f216443ebf3a18cd78',1,'SredniaSemestralna::Form1']]]
];
