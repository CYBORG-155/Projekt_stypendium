var searchData=
[
  ['howmeany_86',['howMeany',['../class_srednia_semestralna_1_1_form1.html#a238e9094adf81ba1efe9d17ebf4fea20',1,'SredniaSemestralna::Form1']]]
];
