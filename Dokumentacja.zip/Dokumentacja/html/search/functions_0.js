var searchData=
[
  ['buttonpressme_5fclick_63',['buttonPressMe_Click',['../class_srednia_semestralna_1_1_form1.html#a5fe42197f5617f76aed4a8a50c3085d4',1,'SredniaSemestralna::Form1']]],
  ['buttonsum_5fclick_64',['buttonSum_Click',['../class_srednia_semestralna_1_1_form1.html#ab6885dae8a3723c2fa2573c91a4cc8a9',1,'SredniaSemestralna::Form1']]]
];
