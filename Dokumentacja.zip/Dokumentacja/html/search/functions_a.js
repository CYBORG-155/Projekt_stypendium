var searchData=
[
  ['textbox1_5ftextchanged_77',['textBox1_TextChanged',['../class_srednia_semestralna_1_1_form1.html#aa39a8278890cef7cdccbfcec0e0b3a0f',1,'SredniaSemestralna::Form1']]],
  ['textbox2_5ftextchanged_78',['textBox2_TextChanged',['../class_srednia_semestralna_1_1_form1.html#acbddd026ba410b247d3d1a7abb0d766c',1,'SredniaSemestralna::Form1']]],
  ['textboxaverage_5ftextchanged_79',['textBoxAverage_TextChanged',['../class_srednia_semestralna_1_1_form1.html#a837ba5ace6137bf30d2f192ee958a0fa',1,'SredniaSemestralna::Form1']]],
  ['textboxpoints_5ftextchanged_80',['textBoxPoints_TextChanged',['../class_srednia_semestralna_1_1_form1.html#a3685819ac4ad239f9e42f384f4ca3093',1,'SredniaSemestralna::Form1']]]
];
