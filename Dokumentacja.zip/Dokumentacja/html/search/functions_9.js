var searchData=
[
  ['subjectcreation_76',['subjectCreation',['../class_srednia_semestralna_1_1_form1.html#a75a661891af00f9d1d1f68a81ce6ac4c',1,'SredniaSemestralna::Form1']]]
];
